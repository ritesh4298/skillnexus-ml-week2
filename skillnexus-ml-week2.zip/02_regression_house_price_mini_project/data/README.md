# Data for the house price notebook

1. Go to Kaggle -> "House Prices - Advanced Regression Techniques" -> Data tab.
2. Download `train.csv`.
3. Put it in this folder with the same name: `train.csv`.
