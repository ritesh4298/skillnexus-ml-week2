# Data for the classification notebook

1. Go to Kaggle -> "Titanic - Machine Learning from Disaster" -> Data tab.
2. Download `train.csv`.
3. Rename it to `titanic.csv` and put it in this folder.

(If the file is missing, the notebook tries `seaborn.load_dataset("titanic")`, which needs internet.)
