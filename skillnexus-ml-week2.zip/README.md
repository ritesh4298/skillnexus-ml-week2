# Skill Nexus ML Internship - Week 2 (Supervised Learning)

Hi, I'm Ritesh, a 2nd year B.Tech CSE student. This repo has my Week 2 work for the Machine Learning internship.
I tried to explain every step inside the notebooks (what I did and why), mostly so that I remember it myself.

## What's inside

| Folder | What it covers |
|---|---|
| `01_classification_practice_set/` | Practice set: Logistic Regression on Titanic, confusion matrix and accuracy, Decision Tree vs KNN, tuning `max_depth` |
| `02_regression_house_price_mini_project/` | Assignment 1 + Mini Project 2: Linear Regression for house price prediction, R² score, predicted vs actual plot (plus an improved model and Ridge as extra) |

## How to run

1. Install Python 3.9+ and then in a terminal inside this folder:
   ```
   pip install -r requirements.txt
   jupyter notebook
   ```
2. Download the datasets from Kaggle (steps are in each `data/README.md`).
3. Open a notebook and use **Kernel -> Restart & Run All**.

You can also use Google Colab: upload the notebook and the CSV file, then run all cells.

## Concepts I practiced
- Train/test split, stratified split, random seed
- Handling missing values and encoding categorical data (one-hot)
- Feature scaling and why KNN needs it
- Logistic Regression, Decision Tree, KNN, Linear Regression, Ridge
- Accuracy, precision, recall, F1, confusion matrix, R², MAE, RMSE
- Overfitting vs underfitting, tuning with cross-validation
- Pipelines and ColumnTransformer in scikit-learn

## Note
Datasets are not included in the repo, so download them yourself. The results (numbers and plots) appear when you run the notebooks.
